Work done:
Implemented Monte Carlo method for

What I learned:
How to implement Monte Carlo. Also a few bits about threads

NOTE TO PEER GRADERS:
The program works and compiles in visual studio and on the linux server with the Makefile.
However, due to the inclusion of the c++11 library <thread>, you may have issues compiling
with your specific compiler. For some reason there are compilers that support most c++11
features but not the thread library (g++ needs some update/download to support threads
on windows).

When commenting feedback indicate how long it took the opponent to calculate
its first move and whether you won the game. No reason other than just curiosity.

for me, first move took 56 seconds to calculate.
I won the game but just barley.



Also good luck on finals!