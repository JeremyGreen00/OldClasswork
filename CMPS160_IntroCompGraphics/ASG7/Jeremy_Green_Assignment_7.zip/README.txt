CMPS 160's assignment 7
Jeremy Green
Jeremy_Green_Assignment_7.zip

https://people.ucsc.edu/~jgreen3/cmps160/asgn7/driver.html

May have trouble on Chrome browsers

Explore a forest and discover all 4 teapot pedestals!
Don't get scared

Note: due to the way teapots work collecting one may cause others to dissapear.
So long as you find the pedestals you'll know where they're supposed to be.

Press esc to unlock mouse