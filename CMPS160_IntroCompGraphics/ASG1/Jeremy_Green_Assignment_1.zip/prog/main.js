/**
 * Function called when the webpage loads.
 */
var canvas
var gl
function main() {

  // Retrieve <canvas> element
  canvas = document.getElementById('webgl')
  // Get the rendering context for WebGL
  gl = getWebGLContext(canvas)

  if (!gl) 
  {  
    console.log('Failed to get the rendering context for WebGL'); 
    return;
  }

  // Initialize shaders
  if (!initShaders(gl, ASSIGN1_VSHADER, ASSIGN1_FSHADER)) 
  {
  	console.log('Failed to initialize shaders.');
  	return;
  }

  initEventHandelers()

  // Specify the color for clearing <canvas> 
  gl.clearColor(0.0, 0.0, 0.0, 1.0)
  render()
}